<header class="header">

    <div id="menu-btn" class="fas fa-bars"></div>

    <a href="#" class="logo"> <span>WaVe👋</span>– MoRE</a>

    <div class="navbar">
	    <nav>
	      <ul>
	        <li><a href="homepage.php">home</a></li>
			
		    <li><a href="about us.php">about us</a> 
			    <ul>
				    <li><a href="#">Mission</a></li>
					<li><a href="#">Vision</a></li>
					<li><a href="#">Our Team</a></li>
				</ul>
			</li>
            <li><a href="VehicleMenu.php">vehicle Fleet</a>

            	<!--
			    <ul>
                    <li><a href="#">Luxury Cars</a></li>
					<li><a href="#">Premium Cars</a></li>
					<li><a href="#">General Cars</a></li>
					<li><a href="#">Buses,Vans</a></li>
					<li><a href="#">Lorries,Trucks</a></li>
					<li><a href="#">Three Wheelers</a></li>
					<li><a href="#">Motor Bicycles</a></li>
				</ul>-->
            </li>
            <li><a href="#services">services</a>
			    <ul>
				    <li><a href="#">Self Drive</a></li>
					<li><a href="#">Tours / Chauffeur Driven</a></li>
					<li><a href="#">Weddings & Events</a></li>
					<li><a href="#">Airport / City Transfers</a></li>
					<li><a href="#">Oil Change</a></li>
					<li><a href="#">24/7 Support</a></li>
				</ul>
			</li>
            <li><a href="#rates">rates</a>
			    <ul>
				    <li><a href="#">Self Drive Rates</a></li>
					<li><a href="#">With Driver Rates</a></li>
				</ul>
			</li>
		    <li><a href="feedbackManage.php">feedback</a>
              <!--  <ul>
                    <li><a href="#">Customer</a></li>
                    <li><a href="#">Driver</a></li>
                    <li><a href="#">Other</a></li>
                </ul>-->
            </li>
            <li><a href="#contact us">contact Us</a></li>
            <li><a href="profile.php">profile</a></li>
         <!--   <li><a href="adminLogin.php">admin</a></li>-->
	    </ul>
	 </nav>
    </div>

    <div id="login-btn">
        <a href="loging.php">
        <button class="btn">login</button></a>
        <i class="far fa-user"></i>
    </div>
	
	<div id="login-btn">
        <a href="signUp.php">
        <button class="btn">Sign Up</button></a>
        <i class="far fa-user"></i>
    </div>
	
</header> 
 